# Note that this file is generated during install.
__version__ = '0.10.0a0+0b261b9'
